## 2026-07-15 23:04:19.558Z load
- url: https://0ae1345e-a02f-4c9c-8392-518f91c39015.app-preview.com/?t=1784154469217#top

## 2026-07-15 23:06:16.482Z click
- element: {"tag":"nav","role":null,"ariaLabel":null,"name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"</>DevClubEcossistemaTrilhasHistóriasTutoresConteúdos GratuitosComeçar"}

## 2026-07-15 23:06:40.055Z click
- element: {"tag":"button","role":null,"ariaLabel":"Abrir menu","name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":""}

## 2026-07-15 23:06:41.887Z click
- element: {"tag":"button","role":null,"ariaLabel":null,"name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"Conteúdos Gratuitos"}

## 2026-07-15 23:06:52.408Z click
- element: {"tag":"span","role":null,"ariaLabel":null,"name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":" @canaldevclub"}

## 2026-07-15 23:06:53.031Z click
- element: {"tag":"span","role":null,"ariaLabel":null,"name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":" @canaldevclub"}

## 2026-07-15 23:06:57.238Z click
- element: {"tag":"button","role":null,"ariaLabel":"Fechar","name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":""}

