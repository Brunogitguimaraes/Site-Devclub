# Codebase Map

npm workspaces monorepo at `/home/${username}/websites/${sandboxId}/public_html`. The web app ships standalone. Call `enable_pocketbase_integration` to add a database, or `enable_api_server_integration` to add an Express backend — each tool appends its own `## apps/<service>` section to this file.

## apps/web (React + Vite + Tailwind + shadcn/ui, port 3000)

Located at apps/web/. Run: `cd apps/web && npm run dev` (auto-started by the sandbox supervisor).
src/main.jsx — entry point, mounts <App />
src/App.jsx — React Router, all routes defined here
src/index.css — Tailwind theme, CSS variables, DevClub dark/neon-green design system with typography and animations
src/pages/HomePage.jsx — "/" route, DevClub landing page with all sections, includes YouTubeModal and FloatingActions
src/components/ScrollToTop.jsx — resets scroll on route change
src/components/ui/ — shadcn/ui primitives — import from `@/components/ui/<name>`, do not edit the files
src/hooks/use-mobile.jsx — mobile breakpoint detection
src/hooks/use-toast.js — toast notifications
src/lib/utils.js — cn() Tailwind class merge
src/data/devclub.js — content data: formations, stories, tutors, companies, ecosystem items, metrics
src/components/devclub/Loader.jsx — initial loader animation, 1.5s max
src/components/devclub/Cursor.jsx — custom cursor on desktop (discrete, non-intrusive)
src/components/devclub/Nav.jsx — fixed navigation bar, changes appearance per section background, includes "Conteúdos Gratuitos" link that opens YouTubeModal
src/components/devclub/YouTubeModal.jsx — elegant modal displaying DevClub YouTube channel and latest videos in grid, dark/neon-green design, closeable
src/components/devclub/FloatingActions.jsx — fixed floating action buttons (WhatsApp and AI Support) in bottom-right corner with hover depth effects, responsive
src/components/devclub/Constellation.jsx — interactive canvas with mouse parallax, node constellation for hero
src/components/devclub/Counter.jsx — animated number counter for metrics
src/components/devclub/CinematicBackdrop.jsx — hero background with four-scene montage (journey, collaboration, construction, celebration), Ken Burns crossfades, dark overlay for text legibility
src/components/devclub/IntroReveal.jsx — 3-second entrance animation with converging lines, particles, and sweep effect, respects prefers-reduced-motion
src/components/devclub/Hero.jsx — cinematographic hero section with cinematic backdrop, intro reveal animation, constellation, choreographed entrance, scroll indicator, dual CTAs
src/components/devclub/SocialStrip.jsx — continuous marquee with social proof messages and icons
src/components/devclub/Manifesto.jsx — editorial section with word-by-word reveal, evolution map interactive element
src/components/devclub/Ecosystem.jsx — interactive career OS panel with five areas (Formations, Mentorships, Community, Real Projects, Opportunities), content-switching on selection
src/components/devclub/Tracks.jsx — formations as evolution trails with duration, level, skills, progress state, horizontal scroll on mobile
src/components/devclub/Stories.jsx — transformation stories with featured story (asymmetric layout), timeline, draggable carousel of testimonials
src/components/devclub/Companies.jsx — dynamic company logos wall with slow movement, connection lines, impact metrics with entrance animations
src/components/devclub/Tutors.jsx — tutors as real people with photos, specialties, short phrases, interactive channel-like navigation
src/components/devclub/FinalCTA.jsx — apex section with abstract terminal/code flow background, large green CTA button, motivational copy
src/components/devclub/Footer.jsx — minimal, elegant footer with links and branding
vault/wiki/skills/design/SKILL.md — frontend craft, styling, typography, motion, and shadcn policy for UI surfaces.
apps/web/plugins/session-journal/ — infrastructure, DO NOT edit. Vite dev plugin injects the browser session journal client; events go over HMR (`import.meta.hot.send('session-journal:event', …)`); the plugin arranges persistence under `vault/temp/SESSION_JOURNAL.md`.
Routes: / → HomePage (DevClub landing page with YouTube modal and floating actions)
