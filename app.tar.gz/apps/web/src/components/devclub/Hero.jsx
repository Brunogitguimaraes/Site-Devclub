import React from 'react';
import { motion } from 'framer-motion';
import { ArrowRight, PlayCircle } from 'lucide-react';
import Constellation from './Constellation';
import CinematicBackdrop from './CinematicBackdrop';
import IntroReveal from './IntroReveal';

const container = {
  hidden: {},
  show: { transition: { staggerChildren: 0.12, delayChildren: 0.15 } },
};
const rise = {
  hidden: { opacity: 0, y: 28 },
  show: { opacity: 1, y: 0, transition: { duration: 0.7, ease: [0.22, 1, 0.36, 1] } },
};

export default function Hero() {
  return (
    <section id="top" className="relative min-h-[100dvh] overflow-hidden">
      <IntroReveal />
      <CinematicBackdrop />
      <div className="absolute inset-0 dc-grid opacity-[0.2]" />
      <div className="absolute inset-0 dc-radial-glow" />
      <Constellation className="absolute inset-0 h-full w-full opacity-70" />
      <div className="pointer-events-none absolute inset-0 bg-gradient-to-b from-background/10 via-transparent to-background" />

      <div className="relative mx-auto flex min-h-[100dvh] max-w-[90rem] flex-col justify-center px-5 pb-24 pt-28 md:px-8">
        <motion.div variants={container} initial="hidden" animate="show" className="max-w-5xl">
          <motion.div variants={rise} className="mb-8 flex items-center gap-3 font-mono text-xs uppercase tracking-[0.2em] text-muted-foreground">
            <span className="h-1.5 w-1.5 rounded-full" style={{ background: 'hsl(var(--dc-green))', boxShadow: '0 0 12px hsl(var(--dc-green))' }} />
            sistema de evolução profissional
          </motion.div>

          <h1 className="font-display text-[13vw] font-black uppercase leading-[0.9] sm:text-[10vw] lg:text-[7.5rem]">
            <motion.span variants={rise} className="block">Você não veio</motion.span>
            <motion.span variants={rise} className="block">até aqui para</motion.span>
            <motion.span variants={rise} className="block text-glow" style={{ color: 'hsl(var(--dc-green))' }}>
              ficar no mesmo lugar.
            </motion.span>
          </h1>

          <motion.p variants={rise} className="mt-8 max-w-xl text-base text-muted-foreground md:text-lg">
            Aprenda tecnologia construindo projetos reais, dentro de uma comunidade
            que transforma esforço em oportunidade. Do primeiro código à primeira
            grande conquista.
          </motion.p>

          <motion.div variants={rise} className="mt-10 flex flex-col gap-3 sm:flex-row">
            <a
              href="#ecossistema"
              className="group inline-flex items-center justify-center gap-2 rounded-md px-7 py-4 font-semibold text-background transition-transform hover:-translate-y-0.5 active:scale-[0.98]"
              style={{ background: 'hsl(var(--dc-green))' }}
            >
              Conhecer o ecossistema
              <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
            </a>
            <a
              href="#historias"
              className="inline-flex items-center justify-center gap-2 rounded-md border border-border px-7 py-4 font-semibold transition-colors hover:border-foreground/40 hover:bg-secondary"
            >
              <PlayCircle className="h-4 w-4" />
              Ver histórias reais
            </a>
          </motion.div>
        </motion.div>
      </div>

      <motion.a
        href="#prova"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.4, duration: 0.8 }}
        className="absolute bottom-6 left-1/2 hidden -translate-x-1/2 flex-col items-center gap-3 md:flex"
      >
        <span className="font-mono text-[11px] uppercase tracking-[0.2em] text-muted-foreground">
          role para iniciar sua evolução
        </span>
        <span className="relative h-14 w-px overflow-hidden bg-border">
          <motion.span
            className="absolute inset-x-0 top-0 h-6"
            style={{ background: 'linear-gradient(to bottom, transparent, hsl(var(--dc-green)))' }}
            animate={{ y: [-24, 56] }}
            transition={{ duration: 1.8, repeat: Infinity, ease: 'easeInOut' }}
          />
        </span>
      </motion.a>
    </section>
  );
}
